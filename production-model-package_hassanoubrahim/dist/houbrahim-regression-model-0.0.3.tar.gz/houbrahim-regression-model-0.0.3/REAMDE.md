
# upload 

- pip install twine
- python3 setup.py sdist bdist_wheel
- twine upload dist/* 

# install package
![](images/img.png)

